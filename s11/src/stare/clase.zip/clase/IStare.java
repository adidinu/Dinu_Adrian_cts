package stare.clase;

public interface IStare {
    void modificareStare(Bancomat bancomat);
}
